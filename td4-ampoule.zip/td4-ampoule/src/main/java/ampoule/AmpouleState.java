package ampoule;

public interface AmpouleState {
    void allumer(Ampoule a);
    void eteindre(Ampoule a);
    void reparer(Ampoule a);
}
