runner {
    parallel {
        enabled false
    }
}
