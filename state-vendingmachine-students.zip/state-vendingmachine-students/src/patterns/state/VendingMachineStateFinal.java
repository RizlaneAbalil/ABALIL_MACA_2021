package patterns.state;

public class VendingMachineStateFinal {
}
