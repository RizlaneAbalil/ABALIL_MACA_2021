package patterns.state;

public class SimpleVendingMachineStateBegin {
}
